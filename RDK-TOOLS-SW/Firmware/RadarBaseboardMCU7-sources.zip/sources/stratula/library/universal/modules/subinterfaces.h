/****************************************************************************\
* Copyright (C) 2020 Infineon Technologies
*
* THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY
* KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
* IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
* PARTICULAR PURPOSE.
*
\****************************************************************************/

/*********************************************************************************************************************/
/************************************************** Module SubInterfaces *********************************************/
/*********************************************************************************************************************/
#define MODULE_SUBIF_DEFAULT            0x00
