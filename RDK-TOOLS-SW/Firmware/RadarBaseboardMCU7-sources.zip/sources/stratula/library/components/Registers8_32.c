#include "Registers8_32.h"

#define RegistersType Registers8_32

#include "Registers.inc"
