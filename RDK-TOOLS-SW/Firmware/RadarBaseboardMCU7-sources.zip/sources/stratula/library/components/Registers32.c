#include "Registers32.h"

#define RegistersType Registers32

#include "Registers.inc"
