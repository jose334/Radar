#include "Registers8_16.h"

#define RegistersType Registers8_16

#include "Registers.inc"
