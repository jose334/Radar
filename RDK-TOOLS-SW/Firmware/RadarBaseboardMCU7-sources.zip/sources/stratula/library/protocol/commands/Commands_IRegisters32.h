#ifndef COMMANDS_I_REGISTERS_32_H
#define COMMANDS_I_REGISTERS_32_H 1

#include <components/interfaces/IRegisters32.h>
#include <stdint.h>


/** Writes a burst of Radar register values
 *
 *  @param wIndex  unused
 *  @param wLength length in bytes of payload buffer containing "n + 1" 32-bit words where:
                   n = number of 32-bit Radar register values
 *  @param payload buffer containing "n + 1" 32-bit words distributed as:
 *                                        if n > 0:
 *                 payload[0] = 32-bit Radar register address, lowest byte
 *                 payload[1] = 32-bit Radar register address, 2nd lowest byte
 *                 payload[2] = 32-bit Radar register address, 3rd lowest byte
 *                 payload[3] = 32-bit Radar register address, high byte
 *
 *                 payload[0 + (n)*2] = n-th 32-bit Radar register value, lowest byte
 *                 payload[1 + (n)*2] = n-th 32-bit Radar register value, 2nd lowest byte
 *                 payload[2 + (n)*2] = n-th 32-bit Radar register value, 3rd lowest byte
 *                 payload[3 + (n)*2] = n-th 32-bit Radar register value, high byte
 *
 *  @return bStatus STATUS_SUCCESS if parameters were valid and execution successful
 *                  STATUS_REQUEST_LENGTH_INVALID if wLength is not multiple of 4, plus 1
 *                  E_INVALID_PARAMETER if id maps to a non existing Radar module
 *                  E_FAILED if parameters were valid but execution failed
 */
uint8_t Commands_IRegisters32_writeRegisterBurst(IRegisters32 *registers, uint16_t wIndex, uint16_t wLength, const uint8_t *payload);

/** Set Radar Bits on a given register
 *
 *  @param wIndex  unused
 *  @param wLength must be 8
 *  @param payload buffer containing:
 *                 payload[0] = 32-bit register address, lowest byte
 *                 payload[1] = 32-bit register address, 2nd lowest byte
 *                 payload[2] = 32-bit register address, 3rd lowest byte
 *                 payload[3] = 32-bit register address, high byte
 *
 *                 payload[4] = 32-bit mask, lowest byte
 *                 payload[5] = 32-bit mask, 2nd lowest byte
 *                 payload[6] = 32-bit mask, 3rd lowest byte
 *                 payload[7] = 32-bit mask, high byte
 *
 *  @return bStatus STATUS_SUCCESS if parameters were valid and execution successful
 *                  STATUS_REQUEST_LENGTH_INVALID if wLength has incorrect value
 *                  E_INVALID_PARAMETER if id maps to a non existing Radar module
 *                  E_FAILED if parameters were valid but execution failed
 */
uint8_t Commands_IRegisters32_setRegisterBits(IRegisters32 *registers, uint16_t wIndex, uint16_t wLength, const uint8_t *payload);

/** Clear Radar Bits on a given register
 *
 *  @param wIndex  unused
 *  @param wLength must be 8
 *  @param payload buffer containing:
 *                 payload[0] = 32-bit register address, lowest byte
 *                 payload[1] = 32-bit register address, 2nd lowest byte
 *                 payload[2] = 32-bit register address, 3rd lowest byte
 *                 payload[3] = 32-bit register address, high byte
 *
 *                 payload[4] = 32-bit mask, lowest byte
 *                 payload[5] = 32-bit mask, 2nd lowest byte
 *                 payload[6] = 32-bit mask, 3rd lowest byte
 *                 payload[7] = 32-bit mask, high byte
 *
 *  @return bStatus STATUS_SUCCESS if parameters were valid and execution successful
 *                  STATUS_REQUEST_LENGTH_INVALID if wLength has incorrect value
 *                  E_INVALID_PARAMETER if id maps to a non existing Radar module
 *                  E_FAILED if parameters were valid but execution failed
 */
uint8_t Commands_IRegisters32_clearRegisterBits(IRegisters32 *registers, uint16_t wIndex, uint16_t wLength, const uint8_t *payload);

/** Modify Radar Bits on a given register
 *
 *  @param wIndex  unused
 *  @param wLength must be 12
 *  @param payload buffer containing:
 *                 payload[0] = 32-bit register address, lowest byte
 *                 payload[1] = 32-bit register address, 2nd lowest byte
 *                 payload[2] = 32-bit register address, 3rd lowest byte
 *                 payload[3] = 32-bit register address, high byte
 *
 *                 payload[4] = 32-bit "set" mask, lowest byte
 *                 payload[5] = 32-bit "set" mask, 2nd lowest byte
 *                 payload[6] = 32-bit "set" mask, 3rd lowest byte
 *                 payload[7] = 32-bit "set" mask, high byte
 *
 *                 payload[8] = 32-bit "clear" mask, lowest byte
 *                 payload[9] = 32-bit "clear" mask, 2nd lowest byte
 *                 payload[10] = 32-bit "clear" mask, 3rd lowest byte
 *                 payload[11] = 32-bit "clear" mask, high byte
 *
 *  @return bStatus STATUS_SUCCESS if parameters were valid and execution successful
 *                  STATUS_REQUEST_LENGTH_INVALID if wLength has incorrect value
 *                  E_INVALID_PARAMETER if id maps to a non existing Radar module
 *                  E_FAILED if parameters were valid but execution failed
 */
uint8_t Commands_IRegisters32_modifyRegisterBits(IRegisters32 *registers, uint16_t wIndex, uint16_t wLength, const uint8_t *payload);

/** Reads a burst of Radar register values
 *
 *  @param wIndex  unused
 *  @param wLength length in bytes of expected return values (i.e. 4 * "n" expected 32-bit return values)
 *  @param payload buffer (32-bit aligned) initially containing:
 *                                        if wLength > 0, n=wLength/4:
 *                 payload[0] = 32-bit Radar register address, lowest byte
 *                 payload[1] = 32-bit Radar register address, 2nd lowest byte
 *                 payload[2] = 32-bit Radar register address, 3rd lowest byte
 *                 payload[3] = 32-bit Radar register address, high byte
 *
 *                 to which finally Radar register values will be stored:
 *                 payload[0 + (n-1)*2] = n-th 32-bit Radar register value, lowest byte
 *                 payload[1 + (n-1)*2] = n-th 32-bit Radar register value, 2nd lowest byte
 *                 payload[2 + (n-1)*2] = n-th 32-bit Radar register value, 3rd lowest byte
 *                 payload[3 + (n-1)*2] = n-th 32-bit Radar register value, high byte
 *
 *  @return bStatus STATUS_SUCCESS if parameters were valid and execution successful
 *                  STATUS_REQUEST_LENGTH_INVALID if wLength is not multiple of 2
 *                  E_INVALID_PARAMETER if id maps to a non existing Radar module
 *                  E_FAILED if parameters were valid but execution failed
 */
uint8_t Commands_IRegisters32_readRegisterBurst(IRegisters32 *registers, uint16_t wIndex, uint16_t wLength, uint8_t **payload);

#endif /* COMMANDS_I_REGISTERS_32_H */
