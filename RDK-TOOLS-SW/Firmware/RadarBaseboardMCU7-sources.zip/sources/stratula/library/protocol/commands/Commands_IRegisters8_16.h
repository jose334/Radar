#ifndef COMMANDS_I_REGISTERS_8_16_H
#define COMMANDS_I_REGISTERS_8_16_H 1

#include <components/interfaces/IRegisters8_16.h>


#include "Commands_IRegisters.h"

#endif /* COMMANDS_I_REGISTERS_8_16_H */
