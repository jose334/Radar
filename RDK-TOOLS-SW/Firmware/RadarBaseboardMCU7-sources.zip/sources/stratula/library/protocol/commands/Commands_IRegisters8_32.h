#ifndef COMMANDS_I_REGISTERS_8_32_H
#define COMMANDS_I_REGISTERS_8_32_H 1

#include <components/interfaces/IRegisters8_32.h>


#include "Commands_IRegisters.h"

#endif /* COMMANDS_I_REGISTERS_8_32_H */
