#ifndef COMMANDS_I_REGISTERS_16_H
#define COMMANDS_I_REGISTERS_16_H 1

#include <components/interfaces/IRegisters16.h>

#include "Commands_IRegisters.h"

#endif /* COMMANDS_I_REGISTERS_16_H */
