#ifndef COMMANDS_I_REGISTERS_8_H
#define COMMANDS_I_REGISTERS_8_H 1

#include <components/interfaces/IRegisters8.h>


#include "Commands_IRegisters.h"

#endif /* COMMANDS_I_REGISTERS_8_H */
