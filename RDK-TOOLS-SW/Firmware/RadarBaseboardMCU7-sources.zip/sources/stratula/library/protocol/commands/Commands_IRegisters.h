//#ifndef COMMANDS_I_REGISTERS_H
//#define COMMANDS_I_REGISTERS_H 1

#include <stdint.h>


uint8_t COMBINE(Commands_, IRegistersType, _read)(IRegistersType *registers, uint8_t bFunction, uint16_t wLength, uint8_t **payload);
uint8_t COMBINE(Commands_, IRegistersType, _write)(IRegistersType *registers, uint8_t bFunction, uint16_t wLength, const uint8_t *payload);
uint8_t COMBINE(Commands_, IRegistersType, _transfer)(IRegistersType *registers, uint8_t bFunction, uint16_t wLengthIn, const uint8_t *payloadIn, uint16_t *wLengthOut, uint8_t **payloadOut);

//#endif /* COMMANDS_I_REGISTERS_H */
