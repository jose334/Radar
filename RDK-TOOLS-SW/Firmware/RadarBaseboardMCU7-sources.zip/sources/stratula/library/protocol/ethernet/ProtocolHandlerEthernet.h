#ifndef PROTOCOL_HANDLER_ETHERNET_H_
#define PROTOCOL_HANDLER_ETHERNET_H_ 1

#include "../VendorProtocol.h"
#include <common/errors.h>
#include <universal/link_definitions.h>

#include <stdint.h>


#define PROTOCOL_HANDLER_ETHERNET_MAX_PACKET_SIZE ETH_UDP_MAX_PAYLOAD


#define PROTOCOL_HANDLER_ETHERNET_DEFAULT_DATA_IP_ADDR \
    {                                                  \
        169, 254, 255, 255                             \
    }  // broadcast by default
#define PROTOCOL_HANDLER_ETHERNET_CONTROL_PORT 55055
#define PROTOCOL_HANDLER_ETHERNET_DATA_PORT    55056
#define PROTOCOL_HANDLER_ETHERNET_TIMEOUT      200

/** Enable the Ethernet-Udp communication
 * i.e. Establish a connection to PROTOCOL_HANDLER_ETHERNET_REMOTEIPADDR
 * at both PROTOCOL_HANDLER_ETHERNET_CONTROL_PORT and PROTOCOL_HANDLER_ETHERNET_DATA_PORT
 */
void ProtocolHandlerEthernet_Constructor(void);

/** Send a data-packet
 *  See VendorProtocol.h, for more info about data-packets.
 *
 * @param type the type of packet
 * @param count the packet's count value (used for error checking on the host-side)
 * @param length number of bytes of the packet's payload
 * @param payload a pointer to the packet's payload
 *
 */
sr_t ProtocolHandlerEthernet_sendDataPacket(VendorProtocol_DataPacketHeader *header, const uint8_t *payload, uint64_t timestamp);

#endif /* PROTOCOL_HANDLER_ETHERNET_H_ */
