#ifndef PARITY_H
#define PARITY_H 1

#include <stdbool.h>

bool getParity(unsigned int value);

#endif /* PARITY_H */
