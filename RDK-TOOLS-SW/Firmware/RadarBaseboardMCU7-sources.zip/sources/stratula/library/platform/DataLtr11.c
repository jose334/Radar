#include "DataLtr11.h"

#include <fatal_error.h>
#include <impl/chrono.h>

#include <stdbool.h>
#include <stddef.h>
#include <string.h>

#define ERR_READOUT_FAILED 0x012E

IData DataLtr11 = {
    .configure           = DataLtr11_configure,
    .calibrationRequired = DataLtr11_calibrationRequired,
    .calibrate           = DataLtr11_calibrate,
    .start               = DataLtr11_start,
    .stop                = DataLtr11_stop,
    .getStatusFlags      = DataLtr11_getStatusFlags,
    .registerCallback    = DataLtr11_registerCallback,
};

static IData_callback m_callback                  = NULL;
static void *m_arg                                = NULL;
static IData_acquisitionStatusCallback m_statusCb = NULL;

#define DATA_LTR11_MAX_READOUTS (3)  // number of data readouts that can be performed for every IRQ


// maximum supported queue size
#define DATA_LTR11_MAX_PACKETS 1024u

/* header of queue packet
 * The sizeof this structure must be a multiple of 32bits.
 */
typedef struct
{
    chrono_ticks_t ticks;  // ticks (can be converted to timestamp)
    uint32_t gsr0;         // global status register of BGT
} queue_packet_header_t;

/* Queue structure
 *
 * The queue can store up to max_packets of packets. Each packets in the queue
 * fits a payload consisting of multiple uint16_t readout words.
 */
typedef struct
{
    // buffer
    uint32_t bufferSize;  // number of 16-bit words fitting in the buffer
    uint16_t *buffer;

    // current status
    uint32_t idx_read;          // index of next element to be read (packet number), only updated by reader
    uint32_t idx_write;         // index of next element to be written (packet number), only updated by writer
    volatile uint32_t read;     // number of read packets, used for synchronization, only updated by reader
    volatile uint32_t written;  // number of written packets, used for synchronization, only updated by writer

    // sizes and limits
    uint32_t packet_size;  // number of 16-bit words fitting in one packet
    uint32_t max_packets;  // number of packets which fit into the queue

    // packet headers are stored separately to allow contiguous data in the buffer
    queue_packet_header_t packetHeaders[DATA_LTR11_MAX_PACKETS];
} Queue_t;

typedef struct
{
    Queue_t queue;
    uint8_t index;
    uint16_t readoutEntries;                        // data acquisition readouts to be performed for every IRQ to obtain one slice
    uint16_t readouts[DATA_LTR11_MAX_READOUTS][2];  //
    uint32_t frameSlices;                           // frames might consist of 1 slice or be aggregated from multiple slices
    volatile bool running;                          // flag indicating if acquisition is running
    IProtocolLtr11 *protocol;
    IPinsLtr11 *pins;
} DataLtr11_t;

#define DATA_LTR11_MAX_COUNT 1u  // number of data interfaces supported

static DataLtr11_t m_dataLtr11Array[DATA_LTR11_MAX_COUNT] = {{{0}}};


static void queue_reset(Queue_t *queue)
{
    queue->idx_read  = 0;
    queue->idx_write = 0;
    queue->read      = 0;
    queue->written   = 0;
}

static sr_t queue_init(Queue_t *queue, uint16_t packet_size)
{
    queue->packet_size = packet_size;
    queue->max_packets = queue->bufferSize / queue->packet_size;
    if (queue->max_packets == 0)
    {
        return E_NOT_POSSIBLE;
    }

    if (queue->max_packets > DATA_LTR11_MAX_PACKETS)
    {
        queue->max_packets = DATA_LTR11_MAX_PACKETS;
    }

    queue_reset(queue);
    return E_SUCCESS;
}

static void acquisitionStatus(bool state)
{
    if (m_statusCb)
    {
        m_statusCb(state);
    }
}

inline static void errorCallback(uint32_t code, uint8_t channel, uint64_t timestamp)
{
    m_callback(m_arg, NULL, code, channel, timestamp);
}

static void DataLtr11_readyCallback(void *arg)
{
    DataLtr11_t *self = arg;
    Queue_t *queue    = &self->queue;

    /* update write index for the next data fetch */
    const uint32_t idx_write = (queue->idx_write + 1) % queue->max_packets;
    queue->idx_write         = idx_write;  // store write index

    /* update written count, to indicate to reader that another packet has arrived */
    const uint32_t written = queue->written + 1;
    queue->written         = written;  // store written count

    acquisitionStatus(false);
}

static void DataLtr11_fetchCallback(DataLtr11_t *self)
{
    /* Do nothing if data acquisition is not running.
     */
    if (!self->running)
    {
        return;
    }

    Queue_t *queue             = &self->queue;
    const uint32_t max_packets = queue->max_packets;
    const uint32_t read        = queue->read;
    const uint32_t written     = queue->written;
    const bool queue_is_full   = ((uint32_t)(written - read) >= max_packets);

    queue_packet_header_t *header = &queue->packetHeaders[queue->idx_write];
    uint16_t *data                = &queue->buffer[queue->idx_write * queue->packet_size];

    /* initialize header */
    header->ticks = chrono_now();
    header->gsr0  = 0;

    acquisitionStatus(true);

    if (!queue_is_full)
    {
        /* Perform synchronous data readout. Depending on the settings,
         * this might consist of multiple readouts.
         */
        for (uint16_t i = 0; i < self->readoutEntries; i++)
        {
            const uint16_t readoutAddress = self->readouts[i][0];
            const uint16_t readoutCount   = self->readouts[i][1];
            sr_t ret;

            if (readoutAddress == DATA_LTR11_DETECTOR_OUTPUT_VIRTUAL_ADDR)
            {
                uint8_t states;
                ret   = self->pins->getDetectionPins(self->pins, &states);
                *data = states;
            }
            else
            {
                const uint8_t command[2] = LTR11_READ_BURST(readoutAddress);
                ret                      = self->protocol->executeReadBurst(self->protocol, command, readoutCount, data);
            }
            if (ret != E_SUCCESS)
            {
                header->gsr0 = ret;
                break;
            }

            data += readoutCount;
        }
    }
    else
    {
        /* Queue is full, no space left for another package, so *no* data can be fetched.
         * This means, device data is lost. Notify upper layers by sending an error code.
         */
        header->gsr0 = E_OVERFLOW;
    }

    /* Async DMA is not used, because SPI access is controlled by miso arbitration.
     * For this reason, ready callback is invoked here.
     */
    DataLtr11_readyCallback(self);
}

static void PlatformData_fetch(void *arg)
{
    DataLtr11_t *self = (DataLtr11_t *)arg;
    DataLtr11_fetchCallback(self);
}

void DataLtr11_run(void)
{
    if (!m_callback)
    {
        return;
    }

    for (unsigned int index = 0; index < DATA_LTR11_MAX_COUNT; index++)
    {
        DataLtr11_t *self = &m_dataLtr11Array[index];

        if (!self->running)
        {
            continue;
        }

        /* Check if new data packets have been fetched into the queue */
        Queue_t *queue         = &self->queue;
        const uint32_t written = queue->written;
        const uint32_t read    = queue->read;
        if (read == written)
        {
            // queue is empty
            continue;
        }

        /* Transmit enqueued data packets to upper layers */
        const uint32_t idx_read             = queue->idx_read;
        const uint32_t max_packets          = queue->max_packets;
        const uint32_t packet_size          = queue->packet_size;
        uint8_t *payload                    = (uint8_t *)(uintptr_t)&queue->buffer[idx_read * packet_size];
        const queue_packet_header_t *header = &queue->packetHeaders[idx_read];
        const uint64_t timestamp            = chrono_ticks_to_microseconds(header->ticks);
        const uint32_t wordSize             = sizeof(uint16_t);

        /* Check if an error condition occurred */
        bool errors = false;
        if (self->frameSlices > 1)
        {
            // In case a frame is being aggregated, check all slices in the queue
            uint32_t idx_write = queue->idx_write;
            for (uint32_t i = idx_read; i < idx_write; i++)
            {
                const queue_packet_header_t *sliceHeader = &queue->packetHeaders[i];

                if (sliceHeader->gsr0 != E_SUCCESS)
                {
                    errors = true;
                    break;
                }
            }
        }
        else
        {
            // If no aggregation, just check the next slice in the queue
            if (header->gsr0 != E_SUCCESS)
            {
                errors = true;
            }
        }
        if (errors)
        {
            DataLtr11_stop(self->index);
            errorCallback(ERR_READOUT_FAILED, self->index, timestamp);
            continue;
        }

        /* Check if a complete frame is available in the queue.
         * Otherwise the callback function cannot be invoked yet.
         */
        const uint32_t slicesAvailable = written - read;
        if (slicesAvailable < self->frameSlices)
        {
            // complete frame is not yet available
            continue;
        }

        m_callback(m_arg, payload, packet_size * self->frameSlices * wordSize, self->index, timestamp);

        /* Update read index and read count, to indicate to writer that queue space
         * has been freed and that another frame has been transmitted to upper layers.
         */
        queue->idx_read = (idx_read + self->frameSlices) % max_packets;
        queue->read     = read + self->frameSlices;
    }
}

sr_t DataLtr11_calibrationRequired(uint8_t index, double dataRate, bool *isRequired)
{
    *isRequired = false;
    return E_SUCCESS;
}

sr_t DataLtr11_calibrate(uint8_t index)
{
    return E_NOT_AVAILABLE;
}

sr_t DataLtr11_configure(uint8_t index, const IDataProperties_t *dataProperties, const uint8_t *settings, uint16_t settingsSize)
{
    /* Configures the readout parameters for data which is
     * going to be read from the front end device.
     */

    if (index >= DATA_LTR11_MAX_COUNT)
    {
        return E_UNEXPECTED_VALUE;
    }

    DataLtr11_stop(index);

    DataLtr11_t *self    = &m_dataLtr11Array[index];
    self->index          = index;
    self->readoutEntries = 0;  // disable configuration

    const uint16_t readoutEntrySize = sizeof(*self->readouts);
    if ((settingsSize % readoutEntrySize) || (settings == NULL))
    {
        return E_INVALID_SIZE;
    }

    /* The last entry might contain an optional aggregation setting.
     * This is indicated by field [1] (readout count) equal to zero.
     * In such case, field [0] contains the setting.
     */
    uint16_t readoutEntries   = settingsSize / readoutEntrySize;
    const uint16_t *lastEntry = (const uint16_t *)(uintptr_t)&settings[settingsSize - readoutEntrySize];
    if (lastEntry[1] == 0)
    {
        self->frameSlices = lastEntry[0];
        self->frameSlices++;
        readoutEntries--;
    }
    else
    {
        self->frameSlices = 1;  // no aggregation (default)
    }

    // a local copy of the readout entries is needed by the ISR
    if (readoutEntries > DATA_LTR11_MAX_READOUTS)
    {
        return E_INVALID_SIZE;
    }
    memcpy(self->readouts, settings, (readoutEntries * readoutEntrySize));

    // parse and validate readout entries
    uint16_t frameWordCount = 0;
    for (uint16_t i = 0; i < readoutEntries; i++)
    {
        const uint16_t readoutAddress = self->readouts[i][0];
        const uint16_t readoutCount   = self->readouts[i][1];
        if ((readoutCount == 0) || ((readoutAddress == DATA_LTR11_DETECTOR_OUTPUT_VIRTUAL_ADDR) && (readoutCount != 1)))
        {
            return E_INVALID_PARAMETER;
        }
        frameWordCount += readoutCount;  // calculate number of words in frame
    }

    RETURN_ON_ERROR(queue_init(&self->queue, frameWordCount));

    // validate storage capacity required by frame
    Queue_t *queue = &self->queue;
    if (self->frameSlices > queue->max_packets)
    {
        return E_OUT_OF_BOUNDS;
    }

    if (self->frameSlices > 1)
    {
        // trim queue size to ensure frame slice storage is sequential
        queue->max_packets -= queue->max_packets % self->frameSlices;
    }

    self->readoutEntries = readoutEntries;  // enable configuration
    return E_SUCCESS;
}

sr_t DataLtr11_start(uint8_t index)
{
    if (index >= DATA_LTR11_MAX_COUNT)
    {
        return E_UNEXPECTED_VALUE;
    }

    DataLtr11_t *self = &m_dataLtr11Array[index];
    if (self->readoutEntries == 0)
    {
        return E_NOT_CONFIGURED;
    }

    queue_reset(&self->queue);

    self->running = true;

    return E_SUCCESS;
}

sr_t DataLtr11_stop(uint8_t index)
{
    if (index >= DATA_LTR11_MAX_COUNT)
    {
        return E_UNEXPECTED_VALUE;
    }

    DataLtr11_t *self = &m_dataLtr11Array[index];
    self->running     = false;

    acquisitionStatus(false);

    return E_SUCCESS;
}

sr_t DataLtr11_getStatusFlags(uint8_t index, uint32_t *flags)
{
    // TODO: implement if applicable.
    *flags = 0;
    return E_SUCCESS;
}

sr_t DataLtr11_registerCallback(IData_callback callback, void *arg)
{
    m_callback = callback;
    m_arg      = arg;

    return E_SUCCESS;
}

void DataLtr11_setBuffer(uint8_t index, uint16_t *buffer, uint32_t bufferSize)
{
    if (index >= DATA_LTR11_MAX_COUNT)
    {
        fatal_error(FATAL_ERROR_DATA_CONFIG_FAILED);
    }

    DataLtr11_t *self = &m_dataLtr11Array[index];
    if (buffer != NULL)
    {
        self->queue.bufferSize = bufferSize;
        self->queue.buffer     = buffer;
    }
    else
    {
        self->queue.bufferSize = 0;
    }
}

void DataLtr11_initialize(uint8_t index, IProtocolLtr11 *protocol, IPinsLtr11 *pins)
{
    if (index >= DATA_LTR11_MAX_COUNT)
    {
        fatal_error(FATAL_ERROR_DATA_CONFIG_FAILED);
    }

    DataLtr11_t *self = &m_dataLtr11Array[index];

    self->pins     = pins;      // interface used to get the detection pins state
    self->protocol = protocol;  // interface used to fetch data
    protocol->registerCallback(self->protocol, PlatformData_fetch, self);
}

void DataLtr11_Constructor(IData_acquisitionStatusCallback statusCb)
{
    m_statusCb = statusCb;
}
