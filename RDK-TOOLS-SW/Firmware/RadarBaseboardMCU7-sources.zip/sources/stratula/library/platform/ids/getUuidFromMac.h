#ifndef GET_UUID_FROM_MAC_H
#define GET_UUID_FROM_MAC_H 1

#include "getUuid.h"


sr_t getUuidFromMac(uint8_t uuid[UUID_LENGTH]);

#endif /* GET_UUID_FROM_MAC_H */
