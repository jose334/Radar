#ifndef _24CW128X_H
#define _24CW128X_H 1

#include "getMac.h"
#include "getUuid.h"

sr_t _24cw128x_getUuid(uint16_t devAddr, uint8_t uuid[UUID_LENGTH]);

#endif /* _24CW128X_H */
