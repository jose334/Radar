/* ===========================================================================
** Copyright (C) 2021 Infineon Technologies AG
**
** Redistribution and use in source and binary forms, with or without
** modification, are permitted provided that the following conditions are met:
**
** 1. Redistributions of source code must retain the above copyright notice,
**    this list of conditions and the following disclaimer.
** 2. Redistributions in binary form must reproduce the above copyright
**    notice, this list of conditions and the following disclaimer in the
**    documentation and/or other materials provided with the distribution.
** 3. Neither the name of the copyright holder nor the names of its
**    contributors may be used to endorse or promote products derived from
**    this software without specific prior written permission.
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
** AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
** IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
** ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE
** LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
** CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
** SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
** INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
** CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
** ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
** POSSIBILITY OF SUCH DAMAGE.
** ===========================================================================
*/

#ifndef SHIELD_CONNECTOR_DEFINITION_H
#define SHIELD_CONNECTOR_DEFINITION_H 1

#include <stdint.h>
#include <universal/gpio_definitions.h>


typedef struct
{
    uint16_t en_ldo;       ///< LDO (onboard 5 to 3.3 V converter) enable line - onboard
    uint16_t ls_spi_oe;    ///< level shifter (port 1) SPI enable line - onboard
    uint16_t ls_gpio_oe;   ///< level shifter (port 2) GPIO enable line - onboard
    uint16_t ls_gpio_dir;  ///< level shifter (port 2) GPIO direction line - onboard
    uint16_t oc_led;       ///< optional LED on the shield board (open collector mode) - P41 OpenDrain_LED_1
    uint16_t oc1;          ///< open-collector OC1 line used for shield presence detection - P41 OpenDrain1_1
    uint16_t oc2;          ///< open-collector OC2 line used for shield presence detection - P41 OpenDrain2_1
    uint16_t oc3;          ///< open-collector OC3 line - P41 OpenDrain3_1
    uint16_t oc4;          ///< open-collector OC4 line - P41 OpenDrain4_1
} ShieldConnectorDefinition_t;


#endif /* SHIELD_CONNECTOR_DEFINITION_H */
