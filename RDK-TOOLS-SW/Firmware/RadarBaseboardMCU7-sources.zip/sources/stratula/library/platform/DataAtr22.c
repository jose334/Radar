#include "DataAtr22.h"

#include <fatal_error.h>
#include <impl/PlatformI2c.h>
#include <impl/PlatformInterrupt.h>
#include <impl/chrono.h>

#include <stdbool.h>
#include <stddef.h>
#include <string.h>

#define ERR_READOUT_FAILED 0x012E

IData DataAtr22 = {
    .configure           = DataAtr22_configure,
    .calibrationRequired = DataAtr22_calibrationRequired,
    .calibrate           = DataAtr22_calibrate,
    .start               = DataAtr22_start,
    .stop                = DataAtr22_stop,
    .getStatusFlags      = DataAtr22_getStatusFlags,
    .registerCallback    = DataAtr22_registerCallback,
};

static IData_callback m_callback                  = NULL;
static void *m_arg                                = NULL;
static IData_acquisitionStatusCallback m_statusCb = NULL;

#define DATA_ATR22_MAX_READOUTS (8)  // number of data readouts that can be performed for every IRQ


// maximum supported queue size
#define DATA_ATR22_MAX_PACKETS 256u

/* header of queue packet
 * The sizeof this structure must be a multiple of 32bits.
 */
typedef struct
{
    chrono_ticks_t ticks;  // ticks (can be converted to timestamp)
    uint32_t status;       // global status
} queue_packet_header_t;

/* Queue structure
 *
 * The queue can store up to max_packets of packets. Each packets in the queue
 * fits a payload consisting of multiple uint16_t readout words.
 */
typedef struct
{
    // buffer
    uint32_t bufferSize;  // number of 16-bit words fitting in the buffer
    uint16_t *buffer;

    // current status
    uint32_t idx_read;          // index of next element to be read (packet number), only updated by reader
    uint32_t idx_write;         // index of next element to be written (packet number), only updated by writer
    volatile uint32_t read;     // number of read packets, used for synchronization, only updated by reader
    volatile uint32_t written;  // number of written packets, used for synchronization, only updated by writer

    // sizes and limits
    uint32_t packet_size;  // number of 16-bit words fitting in one packet
    uint32_t max_packets;  // number of packets which fit into the queue

    // packet headers are stored separately to allow contiguous data in the buffer
    queue_packet_header_t packetHeaders[DATA_ATR22_MAX_PACKETS];
} Queue_t;

typedef struct
{
    Queue_t queue;
    volatile uint32_t pending;  // flag indicating that acquisition is pending
    uint8_t index;
    uint16_t readoutEntries;                        // data acquisition readouts to be performed for every IRQ to obtain one slice
    uint16_t readouts[DATA_ATR22_MAX_READOUTS][2];  //
    volatile bool running;                          // flag indicating if acquisition is running
    IProtocolAtr22 *protocol;
} DataAtr22_t;

#define DATA_ATR22_MAX_COUNT 4u  // number of data interfaces supported

static DataAtr22_t m_dataAtr22Array[DATA_ATR22_MAX_COUNT] = {{{0}}};


static void queue_reset(Queue_t *queue)
{
    queue->idx_read  = 0;
    queue->idx_write = 0;
    queue->read      = 0;
    queue->written   = 0;
}

static sr_t queue_init(Queue_t *queue, uint16_t packet_size)
{
    queue->packet_size = packet_size;
    queue->max_packets = queue->bufferSize / queue->packet_size;
    if (queue->max_packets == 0)
    {
        return E_NOT_POSSIBLE;
    }

    if (queue->max_packets > DATA_ATR22_MAX_PACKETS)
    {
        queue->max_packets = DATA_ATR22_MAX_PACKETS;
    }

    queue_reset(queue);
    return E_SUCCESS;
}

static void acquisitionStatus(bool state)
{
    if (m_statusCb)
    {
        m_statusCb(state);
    }
}

inline static void errorCallback(uint32_t code, uint8_t channel, uint64_t timestamp)
{
    m_callback(m_arg, NULL, code, channel, timestamp);
}

static void DataAtr22_fetch(DataAtr22_t *self)
{
    if (!self->pending)
    {
        return;
    }

    Queue_t *queue             = &self->queue;
    const uint32_t max_packets = queue->max_packets;
    const uint32_t read        = queue->read;
    const uint32_t written     = queue->written;
    const uint32_t idx_write   = queue->idx_write;

    const bool queue_is_full = ((uint32_t)(written - read) >= max_packets);
    if (queue_is_full)
    {
        /* Queue is full, no space left for another package, so do *not* fetch data yet.
         * Space will be freed once a package is read from the queue in the main loop
         * function DataAtr22_run()
         */
        return;
    }

    /* Queue has enough space, so proceed with data fetch */
    queue_packet_header_t *header = &queue->packetHeaders[idx_write];
    uint16_t *payload             = &queue->buffer[idx_write * queue->packet_size];

    /* initialize header */
    header->ticks  = chrono_now();
    header->status = 0;

    acquisitionStatus(true);

    if (self->pending == 1)
    {
        self->pending--;

        /* Perform synchronous data readout. Depending on the settings,
         * this might consist of multiple readouts.
         */
        for (uint16_t i = 0; i < self->readoutEntries; i++)
        {
            const uint16_t command = self->readouts[i][0];
            const uint16_t count   = self->readouts[i][1];

            const sr_t ret = ProtocolAtr22_executeRead(self->protocol, command, count, payload);
            if (ret != E_SUCCESS)
            {
                header->status = ret;
                break;
            }

            payload += count;
        }
    }
    else
    {
        /* Multiple IRQs are pending. This means, device data is corrupted
         * because previous readouts were not serviced on time. So instead of
         * reading the data, notify upper layers by sending an error code.
         */
        header->status = E_OVERFLOW;
    }

    /* update write index for the next data fetch */
    queue->idx_write = (idx_write + 1) % max_packets;

    /* update written count, to indicate to reader that another packet has arrived */
    queue->written = written + 1;

    acquisitionStatus(false);
}

static void PlatformData_ready(void *arg)
{
    /* Data will be fetched by the main loop function DataAtr22_run() */
    DataAtr22_t *self = (DataAtr22_t *)arg;
    self->pending++;
}

void DataAtr22_run(void)
{
    if (!m_callback)
    {
        return;
    }

    for (unsigned int index = 0; index < DATA_ATR22_MAX_COUNT; index++)
    {
        DataAtr22_t *self = &m_dataAtr22Array[index];

        if (!self->running)
        {
            continue;
        }

        /* New data might be ready to be fetched */
        DataAtr22_fetch(self);

        /* Check if new data packets have been fetched into the queue */
        Queue_t *queue         = &self->queue;
        const uint32_t written = queue->written;
        const uint32_t read    = queue->read;
        if (read == written)
        {
            // queue is empty
            continue;
        }

        /* Transmit enqueued data packets to upper layers */
        const uint32_t idx_read             = queue->idx_read;
        const uint32_t max_packets          = queue->max_packets;
        const uint32_t packet_size          = queue->packet_size;
        uint8_t *payload                    = (uint8_t *)(uintptr_t)&queue->buffer[idx_read * packet_size];
        const queue_packet_header_t *header = &queue->packetHeaders[idx_read];
        const uint64_t timestamp            = chrono_ticks_to_microseconds(header->ticks);
        const uint32_t packet_count         = 1;  // one packet is served at time, i.e. no aggregation is done
        const uint32_t wordSize             = sizeof(uint16_t);

        if (header->status != E_SUCCESS)
        {
            DataAtr22_stop(self->index);
            errorCallback(ERR_READOUT_FAILED, self->index, timestamp);
            continue;
        }

        m_callback(m_arg, payload, packet_size * packet_count * wordSize, self->index, timestamp);

        /* Update read index and read count, to indicate to writer that queue space
         * has been freed and that another frame has been transmitted to upper layers.
         */
        queue->idx_read = (idx_read + packet_count) % max_packets;
        queue->read     = read + packet_count;
    }
}

sr_t DataAtr22_calibrationRequired(uint8_t index, double dataRate, bool *isRequired)
{
    *isRequired = false;
    return E_SUCCESS;
}

sr_t DataAtr22_calibrate(uint8_t index)
{
    return E_NOT_AVAILABLE;
}

sr_t DataAtr22_configure(uint8_t index, const IDataProperties_t *dataProperties, const uint8_t *settings, uint16_t settingsSize)
{
    /* Configures the readout parameters for data which is
     * going to be read from the front end device.
     */

    if (index >= DATA_ATR22_MAX_COUNT)
    {
        return E_UNEXPECTED_VALUE;
    }

    DataAtr22_stop(index);

    DataAtr22_t *self    = &m_dataAtr22Array[index];
    self->index          = index;
    self->readoutEntries = 0;  // disable configuration

    const uint16_t readoutEntrySize = sizeof(*self->readouts);
    if ((settingsSize % readoutEntrySize) || (settings == NULL))
    {
        return E_INVALID_SIZE;
    }

    /* The last entry might contain an optional aggregation setting.
     * This is indicated by field [1] (readout count) equal to zero.
     * In such case, field [0] contains the setting.
     */
    const uint16_t *lastEntry = (const uint16_t *)(uintptr_t)&settings[settingsSize - readoutEntrySize];
    if (lastEntry[1] == 0)
    {
        /* Device has an internal memory which is big enough to store
         * all samples contained in a frame.
         * Therefore, support for aggregation option is not required.
         */
        return E_NOT_SUPPORTED;
    }

    // a local copy of the readout entries is needed by the ISR
    const uint16_t readoutEntries = settingsSize / readoutEntrySize;
    if (readoutEntries > DATA_ATR22_MAX_READOUTS)
    {
        return E_INVALID_SIZE;
    }
    memcpy(self->readouts, settings, (readoutEntries * readoutEntrySize));

    // parse and validate readout entries
    uint16_t frameWordCount = 0;
    for (uint16_t i = 0; i < readoutEntries; i++)
    {
        const uint16_t readoutAddress = self->readouts[i][0];
        const uint16_t readoutCount   = self->readouts[i][1];
        if (readoutCount == 0)
        {
            return E_INVALID_PARAMETER;
        }

        self->readouts[i][0] = ATR22_READ(readoutAddress);  // convert readout address into read command
        frameWordCount += readoutCount;                     // calculate number of words in frame
    }

    RETURN_ON_ERROR(queue_init(&self->queue, frameWordCount));

    self->readoutEntries = readoutEntries;  // enable configuration
    return E_SUCCESS;
}

sr_t DataAtr22_start(uint8_t index)
{
    if (index >= DATA_ATR22_MAX_COUNT)
    {
        return E_UNEXPECTED_VALUE;
    }

    DataAtr22_t *self = &m_dataAtr22Array[index];
    if (self->readoutEntries == 0)
    {
        return E_NOT_CONFIGURED;
    }

    queue_reset(&self->queue);

    self->pending = 0;
    self->running = true;

    return E_SUCCESS;
}

sr_t DataAtr22_stop(uint8_t index)
{
    if (index >= DATA_ATR22_MAX_COUNT)
    {
        return E_UNEXPECTED_VALUE;
    }

    DataAtr22_t *self = &m_dataAtr22Array[index];
    self->running     = false;

    acquisitionStatus(false);

    return E_SUCCESS;
}

sr_t DataAtr22_getStatusFlags(uint8_t index, uint32_t *flags)
{
    // TODO: implement if applicable.
    *flags = 0;
    return E_SUCCESS;
}

sr_t DataAtr22_registerCallback(IData_callback callback, void *arg)
{
    m_callback = callback;
    m_arg      = arg;

    return E_SUCCESS;
}

void DataAtr22_setBuffer(uint8_t index, uint16_t *buffer, uint32_t bufferSize)
{
    if (index >= DATA_ATR22_MAX_COUNT)
    {
        fatal_error(FATAL_ERROR_DATA_CONFIG_FAILED);
    }

    DataAtr22_t *self = &m_dataAtr22Array[index];
    if (buffer != NULL)
    {
        self->queue.bufferSize = bufferSize;
        self->queue.buffer     = buffer;
    }
    else
    {
        self->queue.bufferSize = 0;
    }
}

void DataAtr22_initialize(uint8_t index, IProtocolAtr22 *protocol, const PlatformInterruptDefinition_t *irq)
{
    if (index >= DATA_ATR22_MAX_COUNT)
    {
        fatal_error(FATAL_ERROR_DATA_CONFIG_FAILED);
    }

    DataAtr22_t *self = &m_dataAtr22Array[index];

    self->protocol = protocol;  // interface used to fetch data

    sr_t ret = PlatformInterrupt_registerCallback(irq, PlatformData_ready, self);
    if (ret != E_SUCCESS)
    {
        fatal_error(FATAL_ERROR_DATA_CONFIG_FAILED);
    }
}

void DataAtr22_Constructor(IData_acquisitionStatusCallback statusCb)
{
    m_statusCb = statusCb;
}
