#include "Led.h"

#include <impl/PlatformGpio.h>
#include <stddef.h>


sr_t Led_initialize(const LedDefinition_t *led)
{
    if (led == NULL)
    {
        return E_SUCCESS;
    }

    const uint8_t flags = GPIO_MODE_OUTPUT_PUSH_PULL | (led->activeLow ? GPIO_FLAG_OUTPUT_INITIAL_HIGH : 0);
    return PlatformGpio_configurePin(led->gpio, flags);
}

sr_t Led_set(const LedDefinition_t *led, bool state)
{
    if (led == NULL)
    {
        return E_SUCCESS;
    }

    return PlatformGpio_setPin(led->gpio, state ^ led->activeLow);
}
