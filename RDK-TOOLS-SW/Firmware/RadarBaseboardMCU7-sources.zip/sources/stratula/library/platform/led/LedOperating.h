#ifndef LED_OPERATING_H
#define LED_OPERATING_H 1

#include <platform/led/Led.h>


void LedOperating_Constructor(void);
void LedOperating_run(void);


#endif /* LED_OPERATING_H */
