/* ===========================================================================
** Copyright (C) 2021 Infineon Technologies AG
**
** Redistribution and use in source and binary forms, with or without
** modification, are permitted provided that the following conditions are met:
**
** 1. Redistributions of source code must retain the above copyright notice,
**    this list of conditions and the following disclaimer.
** 2. Redistributions in binary form must reproduce the above copyright
**    notice, this list of conditions and the following disclaimer in the
**    documentation and/or other materials provided with the distribution.
** 3. Neither the name of the copyright holder nor the names of its
**    contributors may be used to endorse or promote products derived from
**    this software without specific prior written permission.
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
** AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
** IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
** ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE
** LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
** CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
** SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
** INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
** CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
** ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
** POSSIBILITY OF SUCH DAMAGE.
** ===========================================================================
*/

#include <PlatformInterfaces.h>
#include <board/Board.h>
#include <bsp/atr22/irq.h>
#include <bsp/atr22/radar.h>
#include <bsp/avian/irq.h>
#include <bsp/avian/radar.h>
#include <bsp/connector.h>
#include <bsp/leds.h>
#include <bsp/ltr11/irq.h>
#include <bsp/ltr11/radar.h>
#include <bsp/spi_custom.h>

#include <board/BoardInfo.h>
#include <common/typeutils.h>
#include <components/radar/Atr22.h>
#include <components/radar/Avian.h>
#include <components/radar/Ltr11.h>
#include <impl/Platform.h>
#include <impl/PlatformGpio.h>
#include <impl/PlatformInterrupt.h>
#include <impl/PlatformSpi.h>
#include <impl/SamsHelper.h>
#include <impl/thread.h>
#include <platform/DataAtr22.h>
#include <platform/DataAvian.h>
#include <platform/DataLtr11.h>
#include <platform/ShieldConnector.h>
#include <platform/led/LedSequenceRbb.h>
#include <platform/led/LedSequenceStatus.h>

#include <protocol/CommandHandlerRadar.h>
#include <protocol/ProtocolHandler.h>
#include <protocol/RequestHandler.h>
#include <protocol/commands/Commands_IRadar.h>

// this includes the implementation of getMac() and getUuid() for the Board
#include <impl/getIdsAtmel.h>

#include <fatal_error.h>


/****************************************************************************
 * Variable declarations
 ****************************************************************************/
static Atr22 m_atr22;
static Avian m_avian;
static Ltr11 m_ltr11;
static IData *m_data = NULL;
#define DATA_BUFFER_SIZE (192 * 1024)
static uint8_t m_dataBuffer[DATA_BUFFER_SIZE] __attribute__((aligned(sizeof(uint32_t))));
#define DATA_ATR22_INDEX_COUNT (ARRAY_SIZE(BoardIrqPinsConfigAtr22[0]))

#define DATA_ATR22_BUFFER_SIZE (16 * 1024)
static uint16_t m_dataAtr22Buffer[DATA_ATR22_INDEX_COUNT][DATA_ATR22_BUFFER_SIZE];

static ShieldConnectorDefinition_t *ShieldConnectorDefinition;
static const IPinsAvianConfig_t *BoardRadarPinsConfigAvian;
extern PlatformSpiDefinition_t *BoardSpiDefinition;
static uint8_t m_shieldConnectorCount;

/****************************************************************************
 * Private methods
 ****************************************************************************/
static void Board_acquisitionStatusCallback(bool state)
{
    if (state)
    {
        LedSequence_setStatus(LED_STATUS_MEASURING);
    }
    else
    {
        LedSequence_setStatus(LED_STATUS_OPERATING);
    }
}

static void Board_dataCallback(void *arg, uint8_t *payload, uint32_t count, uint8_t channel, uint64_t timestamp)
{
    /* Sends data samples to upper layers
     */

    LedSequence_setStatus(LED_STATUS_TRANSFERRING);

    const sr_t ret = ProtocolHandler_sendDataFrame(payload, count, channel, timestamp);
    if (ret != E_SUCCESS)
    {
        m_data->stop(channel);
        ProtocolHandler_resetSendingDataFrames();
    }

    LedSequence_setStatus(LED_STATUS_OPERATING);
}

static sr_t Board_detectShields(void)
{
    /* Checks both connectors for unsupported or wrongly connected shields.
     * In case no errors are detected, both connectors will be enabled,
     * in order to allow radar device detection.
     */
    for (uint8_t shieldId = 0; shieldId < m_shieldConnectorCount; shieldId++)
    {
        // detect the presence of a shield by probing the I2C lines
        const sr_t detection = ShieldConnector_detect(&ShieldConnectorDefinition[shieldId], shieldId);
        switch (detection)
        {
            case E_NOT_AVAILABLE:  // allow shields without I2C bus
                /*  no break */
            case E_SUCCESS:
                break;
            case E_NOT_POSSIBLE:
                LedSequence_setRbbStatus(RBB_ERROR_HARDWARE_CONNECTED_WRONG);
                return E_NOT_POSSIBLE;
                break;
            case E_NOT_SUPPORTED:
                LedSequence_setRbbStatus(RBB_ERROR_HARDWARE_NOT_SUPPORTED);
                return E_NOT_SUPPORTED;
                break;
            default:
                LedSequence_setRbbStatus(RBB_ERROR_HARDWARE_INTERNAL_ERROR);
                return detection;
                break;
        }

        // power-up shield and configure its level shifters
        ShieldConnector_enable(&ShieldConnectorDefinition[shieldId], shieldId, true);
    }

    return E_SUCCESS;
}

static void Board_swapSpiIds(void)
{
    if (ARRAY_SIZE_CHECKED(BoardSpiDefinitionHatvanLegacy) != 2)
    {
        fatal_error(0);
    }

    PlatformSpiDefinition_t tmpSpi    = BoardSpiDefinitionHatvanLegacy[0];
    BoardSpiDefinitionHatvanLegacy[0] = BoardSpiDefinitionHatvanLegacy[1];
    BoardSpiDefinitionHatvanLegacy[1] = tmpSpi;
}

static IRadar *Board_detectRadar(IGpio *gpio, ISpi *spi, II2c *i2c, IData **data)
{
    /* Checks both connectors for the presence of a supported radar device.
     * Only the first detected device will be instantiated.
     */
    for (uint8_t shieldId = 0; shieldId < m_shieldConnectorCount; shieldId++)
    {
        if (m_shieldConnectorCount == 2)
        {
            /* In case there is no radar device on the first connector,
             * swap the ids with the second connector to try detection again.
             * This ensures to always reach the device under devId 0.
             */
            if (shieldId == 1)
            {
                PlatformInterfaces_swapI2cIds();
                Board_swapSpiIds();
            }
        }

        const sr_t avianDetection = Avian_Detect(spi, gpio, &BoardRadarConfigAvian[shieldId], &BoardRadarPinsConfigAvian[shieldId]);
        if (avianDetection == E_SUCCESS)
        {
            Avian_Constructor(&m_avian, &DataAvian, gpio, spi, &BoardRadarConfigAvian[shieldId], &BoardRadarPinsConfigAvian[shieldId]);
            DataAvian_Constructor(Board_acquisitionStatusCallback);
            DataAvian_setBuffer(BoardRadarConfigAvian[shieldId].dataIndex, m_dataBuffer, DATA_BUFFER_SIZE);
            DataAvian_registerInterrupt(BoardRadarConfigAvian[shieldId].dataIndex, &BoardIrqPinsConfigAvian[shieldId]);
            *data = &DataAvian;
            return (IRadar *)&m_avian;
        }

        const sr_t ltr11Detection = Ltr11_Detect(spi, &BoardRadarConfigLtr11[shieldId]);
        if (ltr11Detection == E_SUCCESS)
        {
            Ltr11_Constructor(&m_ltr11, &DataLtr11, gpio, spi, &BoardRadarConfigLtr11[shieldId], &BoardRadarPinsConfigLtr11[shieldId], &BoardIrqPinsConfigLtr11[shieldId]);
            DataLtr11_Constructor(Board_acquisitionStatusCallback);
            DataLtr11_initialize(BoardRadarConfigLtr11[shieldId].dataIndex, (IProtocolLtr11 *)&m_ltr11.m_protocol, (IPinsLtr11 *)&m_ltr11.m_pins);
            uint16_t *ltr11DataBuffer = (uint16_t *)(uintptr_t)m_dataBuffer;
            const uint32_t bufferSize = DATA_BUFFER_SIZE / sizeof(uint16_t);
            DataLtr11_setBuffer(BoardRadarConfigLtr11[shieldId].dataIndex, ltr11DataBuffer, bufferSize);
            *data = &DataLtr11;
            return (IRadar *)&m_ltr11;
        }

        Atr22_WorkaroundEs(gpio, &RadarAtr22PinsConfig[shieldId]);
        const sr_t atr22Detection = Atr22_Detect(i2c, &RadarAtr22Config[shieldId]);
        if (atr22Detection == E_SUCCESS)
        {
            Atr22_Constructor(&m_atr22, &DataAtr22, i2c, &BoardRadarConfigAtr22[shieldId], &RadarAtr22Config[shieldId]);
            DataAtr22_Constructor(Board_acquisitionStatusCallback);
            for (uint8_t i = 0; i < DATA_ATR22_INDEX_COUNT; i++)
            {
                DataAtr22_initialize(i, (IProtocolAtr22 *)&m_atr22.m_protocol, &BoardIrqPinsConfigAtr22[shieldId][i]);
                DataAtr22_setBuffer(i, m_dataAtr22Buffer[i], ARRAY_SIZE(m_dataAtr22Buffer[i]));
            }

            *data = &DataAtr22;
            return (IRadar *)&m_atr22;
        }
    }

    // undo swapping of ids since no radar has been detected
    if (m_shieldConnectorCount == 2)
    {
        PlatformInterfaces_swapI2cIds();
        Board_swapSpiIds();
    }

    LedSequence_setRbbStatus(RBB_ERROR_HARDWARE_NOT_DETECTED);
    return NULL;
}

static bool Board_isHatvanLegacy(void)
{
    /* Detect board type: HatvanPlus or HatvanLegacy.
     * 
     * Pin used for detection:
     * on HatvanPlus labeled as BoardID and connected to a pull-down;
     * on HatvanLegacy labeled as S2_SPI_DIR and connected to a pull-up,
     * as part of 2nd level shifter circuit.
     * 
     * Workaround: need to enable LDO2 to provide 3.3v
     * for pull-up biasing for accurate detection.
     */
    bool isHatvanLegacyBoard;
    const uint16_t detectBoardTypePin = GPIO_ID('A', 8);
    PlatformGpio_configurePin(detectBoardTypePin, GPIO_MODE_INPUT);

    // LDO2 must be enabled as board detection pin pullup needs biasing
    PlatformGpio_configurePin(ShieldConnectorDefinitionHatvanLegacy[1].en_ldo, GPIO_MODE_OUTPUT_PUSH_PULL | GPIO_FLAG_OUTPUT_INITIAL_HIGH);
    this_thread_sleep_for(chrono_milliseconds(1));
    PlatformGpio_getPin(detectBoardTypePin, &isHatvanLegacyBoard);

    // undo LDO2 enabling after reading board type detection pin
    PlatformGpio_configurePin(ShieldConnectorDefinitionHatvanLegacy[1].en_ldo, GPIO_MODE_INPUT);

    return isHatvanLegacyBoard;
}

static bool Board_isHatvanPlusV9Connected(void)
{
    /* Detect which connector on HatvanPlus board is currently in use,
     * by probing the presence of a V9 shield.
     */
    bool oc3, oc4;
    PlatformGpio_configurePin(ShieldConnectorDefinitionHatvanPlus[1].oc3, GPIO_MODE_INPUT_PULL_UP);
    PlatformGpio_configurePin(ShieldConnectorDefinitionHatvanPlus[1].oc4, GPIO_MODE_INPUT_PULL_UP);
    this_thread_sleep_for(chrono_milliseconds(1));
    PlatformGpio_getPin(ShieldConnectorDefinitionHatvanPlus[1].oc3, &oc3);
    PlatformGpio_getPin(ShieldConnectorDefinitionHatvanPlus[1].oc4, &oc4);
    PlatformGpio_configurePin(ShieldConnectorDefinitionHatvanPlus[1].oc3, GPIO_MODE_INPUT);
    PlatformGpio_configurePin(ShieldConnectorDefinitionHatvanPlus[1].oc4, GPIO_MODE_INPUT);
    if (oc3 == 0 && oc4 == 1)
    {
        // V9 shield detected
        return true;
    }
    return false;
}

/****************************************************************************
 * Public methods implementation
 ****************************************************************************/
void Board_Constructor(void)
{
    // initialize platform-specifics and generic low-level platform interfaces
    Platform_Constructor();

    if (!Sams70RevisionA())
    {
        // If this is not Rev. A, trim the suffix from the board name
        boardInfo.name[sizeof(BOARD_NAME_BASE) - 1] = '\0';
    }

    IGpio *gpio = &PlatformGpio;
    ISpi *spi   = &PlatformSpi;
    II2c *i2c   = &PlatformI2c;

    IRadar *radar = NULL;

    // detect board type
    const bool isHatvanLegacy = Board_isHatvanLegacy();
    if (isHatvanLegacy)
    {
        ShieldConnectorDefinition = &ShieldConnectorDefinitionHatvanLegacy[0];
        BoardSpiDefinition        = &BoardSpiDefinitionHatvanLegacy[0];
        BoardRadarPinsConfigAvian = &BoardRadarPinsConfigAvianHatvanLegacy[0];
        m_shieldConnectorCount    = ARRAY_SIZE(ShieldConnectorDefinitionHatvanLegacy);
    }
    else
    {
        // HatvanPlus has two different kinds of connectors and just one is initialized
        if (Board_isHatvanPlusV9Connected())
        {
            ShieldConnectorDefinition = &ShieldConnectorDefinitionHatvanPlus[1];
            BoardSpiDefinition        = &BoardSpiDefinitionHatvanPlus[1];
            BoardRadarPinsConfigAvian = &BoardRadarPinsConfigAvianHatvanPlus[1];
        }
        else
        {
            ShieldConnectorDefinition = &ShieldConnectorDefinitionHatvanPlus[0];
            BoardSpiDefinition        = &BoardSpiDefinitionHatvanPlus[0];
            BoardRadarPinsConfigAvian = &BoardRadarPinsConfigAvianHatvanPlus[0];
        }
        m_shieldConnectorCount = 1;
    }
    PlatformSpi_initialize(BoardSpiDefinition, m_shieldConnectorCount);

    // initialize LedSequence to be used for potential error signaling during detection
    LedSequence_Constructor();
    LedSequence_setStatus(LED_STATUS_OPERATING);

    /*
    1) check for shield connector error
    mirrored connection can only be detected if the shield has I2C pull-ups
    other unexpected levels on OC pins are interpreted as unsupported shield connection
    */

    if (Board_detectShields() == E_SUCCESS)
    {
        /*
        2) Check presence of known devices using SPI and I2C

        try reading the chip ID and instantiate the corresponding driver in the following order
        (only one device is every instantiated)

        - Avian (SPI)
        - LTR11 (SPI)
        - ATR22 (I2C)
        */
        radar = Board_detectRadar(gpio, spi, i2c, &m_data);
    }

    /*
    3) Continue with normal initialization, so that even without a detected device, I2C, SPI, GPIO, etc. are usable
    */

    // Enable communication interface
    RequestHandler_Constructor(gpio, spi, m_data, i2c);
    ProtocolHandler_Constructor();
    CommandHandlerRadar_Constructor();
    if (radar != NULL)
    {
        Commands_IRadar_register(radar);

        // register callback function to handle arriving data
        m_data->registerCallback(Board_dataCallback, NULL);
    }
}

void Board_run(void)
{
    // needs to be called for state machines, etc.
    Platform_run();

    // these run functions can just be called unconditionally, since they will immediately return by default if they are not initialized
    DataAvian_run();
    DataLtr11_run();
    DataAtr22_run();

    // check polling communication interfaces for incoming requests.
    ProtocolHandler_run();

    LedSequence_run();
}
