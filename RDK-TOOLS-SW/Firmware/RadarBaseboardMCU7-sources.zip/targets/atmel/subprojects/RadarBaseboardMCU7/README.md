# Hatvan Firmware

This directory contains the Hatvan firmware and a tool to update the firmware.

## Compiling the Firmware

Open `RadarBaseboardMCU7.atsln` with Atmel Studio 7.0 and compile the code.

## Precompiled Firmwares

Precompiled versions of the firmware can be found in the directory
`UpdateFirmware\bin\firmware`.

## Flashing the Firmware

On Windows you can use the tool provided in the directory `UpdateFirmware` to
flash a new firmware to the Hatvan board.
