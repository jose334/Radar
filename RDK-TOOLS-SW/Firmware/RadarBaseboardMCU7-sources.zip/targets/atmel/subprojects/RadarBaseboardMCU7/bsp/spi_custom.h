/* ===========================================================================
** Copyright (C) 2021 Infineon Technologies AG
**
** Redistribution and use in source and binary forms, with or without
** modification, are permitted provided that the following conditions are met:
**
** 1. Redistributions of source code must retain the above copyright notice,
**    this list of conditions and the following disclaimer.
** 2. Redistributions in binary form must reproduce the above copyright
**    notice, this list of conditions and the following disclaimer in the
**    documentation and/or other materials provided with the distribution.
** 3. Neither the name of the copyright holder nor the names of its
**    contributors may be used to endorse or promote products derived from
**    this software without specific prior written permission.
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
** AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
** IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
** ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE
** LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
** CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
** SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
** INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
** CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
** ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
** POSSIBILITY OF SUCH DAMAGE.
** ===========================================================================
*/

#include <impl/PlatformSpiDefinition.h>


PlatformSpiDefinition_t BoardSpiDefinitionHatvanLegacy[] = {
    [0] = {
        .peripheral_id   = ID_QSPI,
        .baudrate        = 50000000,
        .setup_interface = setup_qspi,

        .addr = {
            .peripheral = QSPI,
            .tdr        = (uint32_t)&QSPI->QSPI_TDR,
            .rdr        = (uint32_t)&QSPI->QSPI_RDR,
        },
        .pins = {
            .csn        = PIO_PA11_IDX,
            .clk        = PIO_PA14_IDX,
            .clk_flags  = IOPORT_MODE_MUX_A,
            .miso       = PIO_PA12_IDX,
            .miso_flags = IOPORT_MODE_MUX_A,
            .mosi       = PIO_PA13_IDX,
            .mosi_flags = IOPORT_MODE_MUX_A,
        },
        .dma = {
            .tx_dma_channel = HV_DMA_HW_CH_TX_1,
            .tx_dma_hw_id   = HV_DMA_HW_INTF_TX_1,
            .rx_dma_channel = HV_DMA_HW_CH_RX_1,
            .rx_dma_hw_id   = HV_DMA_HW_INTF_RX_1,
        },
    },
    [1] = {
        .peripheral_id   = ID_SPI1,
        .baudrate        = 50000000,
        .setup_interface = setup_spi,

        .addr = {
            .peripheral = SPI1,
            .tdr        = (uint32_t)&SPI1->SPI_TDR,
            .rdr        = (uint32_t)&SPI1->SPI_RDR,
        },
        .pins = {
            .csn        = PIO_PC25_IDX,
            .clk        = PIO_PC24_IDX,
            .clk_flags  = IOPORT_MODE_MUX_C,
            .miso       = PIO_PC26_IDX,
            .miso_flags = IOPORT_MODE_MUX_C,
            .mosi       = PIO_PC27_IDX,
            .mosi_flags = IOPORT_MODE_MUX_C,
        },
        .dma = {
            .tx_dma_channel = HV_DMA_HW_CH_TX_2,
            .tx_dma_hw_id   = HV_DMA_HW_INTF_TX_2,
            .rx_dma_channel = HV_DMA_HW_CH_RX_2,
            .rx_dma_hw_id   = HV_DMA_HW_INTF_RX_2,
        },
    },
};

PlatformSpiDefinition_t BoardSpiDefinitionHatvanPlus[] = {
    [0] = {
        .peripheral_id   = ID_QSPI,
        .baudrate        = 50000000,
        .setup_interface = setup_qspi,

        .addr = {
            .peripheral = QSPI,
            .tdr        = (uint32_t)&QSPI->QSPI_TDR,
            .rdr        = (uint32_t)&QSPI->QSPI_RDR,
        },
        .pins = {
            .csn        = PIO_PA11_IDX,
            .clk        = PIO_PA14_IDX,
            .clk_flags  = IOPORT_MODE_MUX_A,
            .miso       = PIO_PA12_IDX,
            .miso_flags = IOPORT_MODE_MUX_A,
            .mosi       = PIO_PA13_IDX,
            .mosi_flags = IOPORT_MODE_MUX_A,
        },
        .dma = {
            .tx_dma_channel = HV_DMA_HW_CH_TX_1,
            .tx_dma_hw_id   = HV_DMA_HW_INTF_TX_1,
            .rx_dma_channel = HV_DMA_HW_CH_RX_1,
            .rx_dma_hw_id   = HV_DMA_HW_INTF_RX_1,
        },
    },
    // For HatvanPlus V9 Connector index 1
    [1] = {
        .peripheral_id   = ID_QSPI,
        .baudrate        = 50000000,
        .setup_interface = setup_qspi,

        .addr = {
            .peripheral = QSPI,
            .tdr        = (uint32_t)&QSPI->QSPI_TDR,
            .rdr        = (uint32_t)&QSPI->QSPI_RDR,
        },
        .pins = {
            .csn        = PIO_PA7_IDX,
            .clk        = PIO_PA14_IDX,
            .clk_flags  = IOPORT_MODE_MUX_A,
            .miso       = PIO_PA12_IDX,
            .miso_flags = IOPORT_MODE_MUX_A,
            .mosi       = PIO_PA13_IDX,
            .mosi_flags = IOPORT_MODE_MUX_A,
        },
        /* Define Quad SPI Pins for Hatvan+: Future use
        .miso_1 = PIO_PA13_IDX  // S1_SPI_MOSI	// DIR2 CTRL
        .miso_2 = PIO_PA17_IDX, // S1_SPI_DIO2	// DIR2 CTRL
        .miso_3 = PIO_PD31_IDX, // S1_DIO3_RSTN // DIR2 CTRL
        */
        .dma = {
            .tx_dma_channel = HV_DMA_HW_CH_TX_1,
            .tx_dma_hw_id   = HV_DMA_HW_INTF_TX_1,
            .rx_dma_channel = HV_DMA_HW_CH_RX_1,
            .rx_dma_hw_id   = HV_DMA_HW_INTF_RX_1,
        },
    },
};
